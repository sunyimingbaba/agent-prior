# 2026-11-13 评分器续训

用户已启动服务器并要求继续。恢复源固定为第 30 轮、960 次优化器更新的完整快照：

`/private/AGSE_E3_1_rebuild_20261112/scorer_training_20261112/attempt_02/snapshots/epoch_30/last.ckpt`

SHA-256：`0c0fe707dac3db1d59a9dedca024977b26a27f7a394d8e7becf84e5efc158583`。

本次根目录为 `/private/AGSE_E3_1_rebuild_20261112/scorer_resume_20261113/`，输出单独保存。模型、数据、缓存、损失、FP32、batch 32、累积 8、单卡 DDP、原学习率调度和 50 轮总上限沿用原方案。剩余 20 轮预计增加 5,000 个批次与 640 次优化器更新，总更新数达到 1,600。

通过 Lightning 原生 `resume_from_checkpoint` 恢复训练。恢复开始时，逐项核对 epoch=30、global_step=960、可训练参数内容、冻结骨干、完整优化器 state_dict 和调度器 state_dict 的哈希。来源学习率为 `4.281650071123755e-05`，调度器 last_epoch=960。

PL 1.4 的 ModelCheckpoint 加载函数仅恢复最佳分数和路径。本次先将前 30 轮最佳文件复制到新检查点目录，再将回调路径指向新副本，补齐 top-k 字典与 kth 值，保留监控值 80.25，并将本次清理操作限定在新目录。最终评分器仍按预先固定的规则选用完成 50 轮后的 last，验证最佳独立保留。

保留昨日的数据模块阶段枚举兼容包装。进程重启种子与 Python 哈希种子均为 0，检查点实际字段列表保存于新配置，续训作为独立版本登记。

服务器预检调用：

```bash
PYTHONUTF8=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=0 /private/AGSE_E1_20261110/legacy/env/bin/python -u /private/AGSE_E3_1_rebuild_20261112/scorer_resume_20261113/train_scorer.py --prepare-only
```

预检核对源码与材料哈希、GPU 种子 0 前向反向见证、阶段枚举、描述顺序与恢复来源，并保存展开配置。独立重放通过后，使用同目录 `run_training.sh` 后台执行；正式恢复的状态核验记录为 `restore_audit.json`，在首批训练之前生成。

训练结束后合并原前 30 轮快照记录与本次 20 轮记录，核对完整 50 轮、12,500 批、1,600 次更新及原生日志指标；随后读取并核验 last/验证最佳检查点，冻结 last，完成服务器、本机与 GitHub 记录备份。
