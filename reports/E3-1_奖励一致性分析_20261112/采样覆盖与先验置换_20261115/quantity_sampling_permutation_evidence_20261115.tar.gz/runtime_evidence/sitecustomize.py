"""Environment-only compatibility for preserved legacy code; no model changes."""
from pathlib import Path

_original = Path('/private/AGSE_E1_20261110/legacy/assets/sitecustomize.py')
exec(compile(_original.read_text(), str(_original), 'exec'))

import torch
import transformers.optimization

# The legacy code imported this removed transformers symbol. This is the same
# torch.optim.AdamW compatibility alias documented in the original deployment.
transformers.optimization.AdamW = torch.optim.AdamW
