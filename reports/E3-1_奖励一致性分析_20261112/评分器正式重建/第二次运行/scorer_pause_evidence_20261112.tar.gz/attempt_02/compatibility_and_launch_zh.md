# 第二次运行：数据模块阶段参数兼容

首次正式入口在 `Trainer.fit → _call_setup_hook → datamodule.setup` 阶段退出。PL 1.4.0 的数据模块追踪器直接将阶段参数拼入属性名；当前 Python 3.12 将 `TrainerFn.FITTING` 格式化为枚举名称，触发 `_has_setup_TrainerFn.FITTING` 属性查找错误。首轮日志、退出码与错误 JSON 保留于父目录 `预检差异/`，服务器首轮输出完整保留。

第二次运行使用新的私有根目录：

`/private/AGSE_E3_1_rebuild_20261112/scorer_training_20261112/attempt_02/`

新入口在 MTDataModule 实例上对已经由 Lightning 包装的 `setup` 和 `teardown` 再添加一层参数转换，先将枚举的 `.value` 传给原追踪器。该处理支持位置参数和关键字参数，随后执行原始数据模块方法。模型、数据集、损失、优化器和环境文件均按原样保留。

包装保留原 hook 的 `__wrapped__` 指向，并在运行时核对 Lightning `is_overridden` 对 setup/teardown 的判定前后一致，维持已有 hook 识别行为。

预检也直接使用 `TrainerFn.FITTING`，核对 `_has_setup_fit` 和 `_has_teardown_fit`，覆盖首轮失败位置。此前仅使用字符串 `fit` 的预检记录继续保留。

```bash
PYTHONUTF8=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=0 /private/AGSE_E1_20261110/legacy/env/bin/python -u /private/AGSE_E3_1_rebuild_20261112/scorer_training_20261112/attempt_02/train_scorer.py --prepare-only
```

预检通过后，独立重放同一调用，再执行同目录 `run_training.sh`。50 轮、FP32、batch 32、累积 8、单卡 DDP、原学习率调度及最终 last 选择策略均沿用已登记方案。训练结果、事件、原生日志与检查点分别落在本次目录下。
