# E3-1 评分器正式重建方案

日期：2026-11-12。上一阶段 1,890 份纯推理先验已经完成逐图核验。本轮以独立入口调用保留的 CUP 模型、数据集、损失、优化器和指标实现，展开并保存实际训练配置。

## 预先固定的训练与选择设置

- UCM train 1,680 张图像用于训练，val 210 张图像用于逐轮验证；每图多个去重描述按原数据集实现展开，共享该图第一条原始描述生成的先验。
- 命名配置：`task_finetune_irtr_ucm_randaug_ViTL14`；ViT-L/14 冻结骨干、prompt 长度 16、agent prior 分支开启。
- 种子 0、单 GPU、单节点、每批 32、梯度累积 8 次，配置目标 batch 为 256。每轮最后的剩余样本与梯度由原 DataLoader 和 Lightning 行为处理，实际批数与优化器步数另存日志。
- 50 轮、学习率 1e-4、warmup 比例 0.1、原 AdamW 参数分组与学习率调度。
- 实际使用 FP32，与原 `run_frozen.py` 中未启用 precision 参数时的行为及已通过的 A100 单步验证一致。原配置默认写有 16，本轮展开配置与 Trainer 均显式登记为 32。
- 保留原单卡 DDP 方式、每轮验证、`val/the_metric` 最大值的最佳文件及 `last.ckpt`。
- 诊断评分器预先固定采用 50 轮结束的 `last.ckpt`；验证最佳文件独立保留。
- 本轮入口执行 `trainer.fit`。原数据模块的 setup 会读取 test 表元数据并创建数据集对象；本轮执行路径包含 train/val 批次及 val 检索评估，独立 test 评估在模型冻结后另行安排。

## 执行与记录

所有输出使用 `/private/AGSE_E3_1_rebuild_20261112/scorer_training_20261112/`。原项目源码、既有模型和数据按原样保留。新入口仅对进程内两处 CLIP 加载函数指定已核验的私有权重路径，并单独组织训练、审计和保存。

运行前核对十四个关键源文件、CLIP 权重、三个 Arrow 文件及纯推理缓存元信息与全部缓存文件。`PYTHONHASHSEED=0` 固定原数据集 `set` 去重后的描述顺序，其实际索引顺序哈希与样本数在预检中登记。

使用已通过实际前向、反向与检查点保存读取验证的私有 legacy 环境。此前的环境账本为 `.aris/compute/school-a100-legacy-20261026.md`，本次有效路径与运行证据见相邻的 A100 接入报告。`run-experiment` 技能引用的共享 `compute-env-contract.md` 在当前技能目录中缺失；本轮沿用已有环境及实际验证记录。

服务器提供 `nohup`，`screen` 和 `tmux` 均未安装，本轮使用独立后台进程、退出码文件、逐批损失、逐轮验证记录和原生日志。每 25 批检查梯度数值与冻结骨干的梯度状态，逐批核对损失有限；训练前后对冻结骨干和可训练参数内容计算哈希。

只展开配置与核对数据的预检调用（在服务器执行）：

```bash
PYTHONUTF8=1 PYTHONHASHSEED=0 CUDA_VISIBLE_DEVICES=0 /private/AGSE_E1_20261110/legacy/env/bin/python -u /private/AGSE_E3_1_rebuild_20261112/scorer_training_20261112/train_scorer.py --prepare-only
```

该调用产生 `resolved_settings.json` 与 `preflight_result.json`，记录实际配置、数据集样本数和索引顺序；预检成功退出码为 0。正式训练通过同目录 `run_training.sh` 启动，使用独立 `run_01.log` 和 `run_01.exit`。

最终对 last 与验证最佳文件分别记录大小、SHA-256、epoch、步数、优化器状态与严格读取结果，再备份本机和私有挂载，并将脚本、配置、日志与登记材料上传 GitHub。大检查点保存在服务器和本机，GitHub 保存其登记哈希及复核证据。
